#' ggpattern: A package of geoms with parameterised pattern fills
#'
#' @description ggpattern: A package of geoms with parameterised pattern fills
#'
#' @docType package
#' @name ggpattern
NULL
